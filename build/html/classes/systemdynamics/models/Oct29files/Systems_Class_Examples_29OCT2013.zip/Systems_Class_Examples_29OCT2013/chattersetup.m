m=10
g=9.8
N=g*m
k=100
mu=.3
v=.3
zv=v/1000
